package prachi.com.activitylifecycle;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.security.Key;

import  prachi.com.activitylifecycle.Global;

public class ActivityA extends AppCompatActivity {

    private static final String COUNTER_KEY = "count";
    private final static String TAG = "ActivityA";
    TextView mTvCounter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_a);


        mTvCounter = (TextView) findViewById(R.id.create);
        if (savedInstanceState != null) {

            Global.mCreate = savedInstanceState.getInt(COUNTER_KEY);
        }
        Log.i(TAG, "Entered the onCreate() method");


        displayCounts();

        Button mActivityBButton = (Button) findViewById(R.id.startActivityB);
        mActivityBButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ActivityA.this, ActiviyB.class);
                startActivity(intent);
            }
        });

        Button mDilougeButton = (Button) findViewById(R.id.dialogButton);
        mDilougeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ActivityA.this, DialogActivity.class);
                startActivity(intent);
            }
        });

        Button mCloseAppButton = (Button) findViewById(R.id.closeAppButton);
        mCloseAppButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


    }

    @Override
    protected void onStart() {
        Log.i(TAG, "Entered the onStart() method");
        super.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();

        ++Global.mCreate;
        Log.i(TAG, "Entered the onResume() method");

        displayCounts();

    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i(TAG, "Entered the onPause() method");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i(TAG, "Entered the onStop() method");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.i(TAG, "Entered the onRestart() method");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i(TAG, "Entered the onDestroy() method");
    }


    public void onSaveInstanceState(Bundle savedInstanceState) {
        // TODO:
        // Save state information with a collection of key-value pairs
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putInt(COUNTER_KEY, Global.mCreate);
    }

    // Updates the displayed counters
    public void displayCounts() {

        mTvCounter.setText("Thread Counter: " + Global.mCreate);

    }
}
