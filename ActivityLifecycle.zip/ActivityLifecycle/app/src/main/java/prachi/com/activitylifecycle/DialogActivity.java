package prachi.com.activitylifecycle;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;

public class DialogActivity extends Activity {

    private static final String COUNTER_KEY = "count";
    private final static String TAG = "DialogActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_dialog);

        Button ok = (Button) findViewById(R.id.dialogButtonOK);
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        if (savedInstanceState != null) {

            Global.mCreate = savedInstanceState.getInt(COUNTER_KEY);
        }

    }

    @Override
    protected void onStart() {
        Log.i(TAG, "Entered the onStart() method");
        super.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();

        ++Global.mCreate;
        Log.i(TAG, "Entered the onResume() method");

    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i(TAG, "Entered the onPause() method");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i(TAG, "Entered the onStop() method");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.i(TAG, "Entered the onRestart() method");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i(TAG, "Entered the onDestroy() method");
    }


    public void onSaveInstanceState(Bundle savedInstanceState) {
        // TODO:
        // Save state information with a collection of key-value pairs
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putInt(COUNTER_KEY, Global.mCreate);
    }


}
