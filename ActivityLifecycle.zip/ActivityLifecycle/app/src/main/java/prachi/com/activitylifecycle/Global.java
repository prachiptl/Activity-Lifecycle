package prachi.com.activitylifecycle;

/**
 * Created by admin on 3/7/2017.
 */
public class Global {
    public static Integer mCreate = 0;

}
